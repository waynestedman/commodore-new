function test () {
	return "Hi there!";
}